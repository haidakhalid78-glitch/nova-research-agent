#!/usr/bin/env python3
import argparse
import datetime as dt
import hashlib
import json
import re
import sqlite3
import time
from pathlib import Path
from urllib.parse import quote_plus

import requests
import yaml
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
REPORTS = ROOT / "reports"
DB = DATA / "research.db"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; NOVA-Free-AI-Video-Research-Agent/1.0)"
}

FREE_PATTERNS = [
    r"\bfree\b", r"\bno credit card\b", r"\bfree plan\b",
    r"\bfree credits?\b", r"\bdaily credits?\b", r"\bmonthly credits?\b"
]
COMMERCIAL_POS = [
    r"commercial (use|license)", r"commercially", r"commercial rights"
]
COMMERCIAL_NEG = [
    r"not included: commercial", r"non-commercial", r"no commercial"
]
WATERMARK_NEG = [r"watermark", r"with watermark"]
WATERMARK_POS = [r"no watermark", r"without watermark"]
RECURRING = [r"daily", r"per day", r"monthly", r"per month", r"weekly", r"reset"]

def load_yaml(name):
    with open(ROOT / name, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def init_db():
    DATA.mkdir(exist_ok=True)
    con = sqlite3.connect(DB)
    con.execute("""
      CREATE TABLE IF NOT EXISTS snapshots (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT NOT NULL,
        tool TEXT NOT NULL,
        source TEXT NOT NULL,
        text_hash TEXT NOT NULL,
        text TEXT NOT NULL
      )
    """)
    con.commit()
    return con

def clean_text(html):
    soup = BeautifulSoup(html, "lxml")
    for tag in soup(["script", "style", "noscript", "svg"]):
        tag.decompose()
    text = soup.get_text(" ", strip=True)
    return re.sub(r"\s+", " ", text)

def fetch(url, timeout=20):
    try:
        r = requests.get(url, headers=HEADERS, timeout=timeout)
        if r.status_code >= 400:
            return None, f"HTTP {r.status_code}"
        return clean_text(r.text), None
    except Exception as e:
        return None, str(e)

def search_web(query, max_results=8):
    url = "https://html.duckduckgo.com/html/?q=" + quote_plus(query)
    text, err = fetch(url)
    if err or not text:
        return []
    soup = BeautifulSoup(requests.get(url, headers=HEADERS, timeout=20).text, "lxml")
    results = []
    for a in soup.select(".result__a")[:max_results]:
        href = a.get("href")
        title = a.get_text(" ", strip=True)
        if href and title:
            results.append({"title": title, "url": href})
    return results

def evidence(text, patterns):
    found = []
    low = text.lower()
    for p in patterns:
        m = re.search(p, low)
        if m:
            start = max(0, m.start() - 90)
            end = min(len(text), m.end() + 180)
            found.append(text[start:end])
    return found[:4]

def analyze(tool, docs):
    combined = " ".join(x["text"] for x in docs if x.get("text"))
    low = combined.lower()
    free = bool(evidence(combined, FREE_PATTERNS))
    recurring = bool(evidence(combined, RECURRING))
    commercial_yes = bool(evidence(combined, COMMERCIAL_POS))
    commercial_no = bool(evidence(combined, COMMERCIAL_NEG))
    watermark_yes = bool(evidence(combined, WATERMARK_NEG))
    watermark_no = bool(evidence(combined, WATERMARK_POS))

    credits = re.findall(
        r"(?i)(\d[\d,]*)\s*(?:free )?(?:credits?|compute units?|generations?)\s*(?:per|/)?\s*(day|daily|month|monthly|week|weekly)?",
        combined
    )
    credits = [f"{n} {period or ''}".strip() for n, period in credits[:8]]

    quality_terms = ["cinematic", "photorealistic", "realistic", "motion", "physics", "1080p", "4k", "720p"]
    multimodal_terms = ["text-to-video", "image-to-video", "reference", "audio", "video-to-video"]
    short_terms = ["tiktok", "reels", "shorts", "social", "vertical"]

    quality_hits = sum(t in low for t in quality_terms)
    multimodal_hits = sum(t in low for t in multimodal_terms)
    short_hits = sum(t in low for t in short_terms)

    score = 0
    score += 25 if recurring else 8 if free else 0
    score += min(20, quality_hits * 4)
    score += min(15, short_hits * 5)
    score += 10 if watermark_no else 0
    score += 15 if commercial_yes and not commercial_no else 5 if not commercial_no else 0
    score += min(10, multimodal_hits * 2)
    score += 5 if docs else 0

    if commercial_no:
        commercial = "NOT INCLUDED / RESTRICTED"
    elif commercial_yes:
        commercial = "Explicitly mentioned; verify current plan/model terms"
    else:
        commercial = "UNCLEAR — verify before monetization"

    return {
        "tool": tool,
        "free_signal": free,
        "recurring_free_signal": recurring,
        "credits_mentions": credits,
        "commercial_use": commercial,
        "watermark": "No watermark signal found" if watermark_no else "Watermark/conditions may apply" if watermark_yes else "Unclear",
        "quality_signals": quality_hits,
        "short_form_signals": short_hits,
        "multimodal_signals": multimodal_hits,
        "score": min(100, score),
        "evidence": {
            "free": evidence(combined, FREE_PATTERNS),
            "recurring": evidence(combined, RECURRING),
            "commercial": (evidence(combined, COMMERCIAL_POS) + evidence(combined, COMMERCIAL_NEG))[:5],
            "watermark": (evidence(combined, WATERMARK_POS) + evidence(combined, WATERMARK_NEG))[:5],
        },
    }

def save_snapshot(con, tool, source, text):
    h = hashlib.sha256(text.encode("utf-8", "ignore")).hexdigest()
    con.execute(
        "INSERT INTO snapshots(ts, tool, source, text_hash, text) VALUES (?, ?, ?, ?, ?)",
        (dt.datetime.utcnow().isoformat() + "Z", tool, source, h, text[:500000])
    )
    con.commit()
    return h

def build_report(results, changes, searches):
    now = dt.datetime.now(dt.timezone.utc).isoformat()
    ordered = sorted(results, key=lambda x: x["score"], reverse=True)
    md = [
        "# NOVA — Free AI Video Research Report",
        "",
        f"Generated: {now}",
        "",
        "## Decision rule",
        "Scores are workflow-fit indicators, not guarantees. Free access, quotas and commercial rights can change by account, region, model and date.",
        "",
        "| Tool | Score | Recurring free signal | Commercial use | Watermark |",
        "|---|---:|---|---|---|",
    ]
    for r in ordered:
        md.append(f"| {r['tool']} | {r['score']}/100 | {'Yes' if r['recurring_free_signal'] else 'No/unclear'} | {r['commercial_use']} | {r['watermark']} |")

    md += ["", "## Recommended 0-DH workflow candidates", ""]
    for r in ordered[:6]:
        md.append(f"### {r['tool']} — {r['score']}/100")
        md.append(f"- Free signal: {r['free_signal']}")
        md.append(f"- Recurring signal: {r['recurring_free_signal']}")
        md.append(f"- Credits mentions: {', '.join(r['credits_mentions']) or 'not detected'}")
        md.append(f"- Commercial: {r['commercial_use']}")
        md.append(f"- Watermark: {r['watermark']}")
        for ev in r["evidence"]["commercial"][:2]:
            md.append(f"- Evidence: {ev}")
        md.append("")

    if changes:
        md += ["## Changes detected since previous run", ""]
        for c in changes:
            md.append(f"- **{c['tool']}** — {c['source']} changed (content hash changed).")
    else:
        md += ["## Changes detected", "No source-content changes detected against the latest stored snapshot."]

    md += ["", "## Discovery queries", ""]
    for q, items in searches.items():
        md.append(f"### {q}")
        for item in items[:5]:
            md.append(f"- {item['title']} — {item['url']}")
    return "\n".join(md), ordered

def run_once():
    cfg = load_yaml("config.yaml")
    src = load_yaml("sources.yaml")
    con = init_db()
    timeout = cfg["agent"].get("request_timeout_seconds", 20)
    results, changes = [], []
    all_searches = {}

    for tool in src["tools"]:
        docs = []
        for url in tool.get("official", []):
            text, err = fetch(url, timeout)
            if text:
                h = hashlib.sha256(text.encode("utf-8", "ignore")).hexdigest()
                prev = con.execute(
                    "SELECT text_hash FROM snapshots WHERE tool=? AND source=? ORDER BY id DESC LIMIT 1",
                    (tool["name"], url)
                ).fetchone()
                if prev and prev[0] != h:
                    changes.append({"tool": tool["name"], "source": url})
                save_snapshot(con, tool["name"], url, text)
                docs.append({"url": url, "text": text})
        results.append(analyze(tool["name"], docs))

    for q in cfg["research_queries"]:
        try:
            all_searches[q] = search_web(q, cfg["agent"].get("max_search_results", 8))
        except Exception as e:
            all_searches[q] = [{"title": "Search error", "url": str(e)}]

    md, ordered = build_report(results, changes, all_searches)
    REPORTS.mkdir(exist_ok=True)
    (REPORTS / "latest.md").write_text(md, encoding="utf-8")
    payload = {
        "generated_at": dt.datetime.now(dt.timezone.utc).isoformat(),
        "results": ordered,
        "changes": changes,
        "searches": all_searches,
    }
    (REPORTS / "latest.json").write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    return payload

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--once", action="store_true")
    p.add_argument("--daily", action="store_true")
    args = p.parse_args()
    if args.once or not args.daily:
        payload = run_once()
        print(json.dumps({
            "status": "ok",
            "report": str(REPORTS / "latest.md"),
            "top_tools": [(x["tool"], x["score"]) for x in payload["results"][:5]]
        }, indent=2))
        return
    cfg = load_yaml("config.yaml")
    hours = float(cfg["agent"].get("interval_hours", 24))
    while True:
        run_once()
        time.sleep(max(300, hours * 3600))

if __name__ == "__main__":
    main()
