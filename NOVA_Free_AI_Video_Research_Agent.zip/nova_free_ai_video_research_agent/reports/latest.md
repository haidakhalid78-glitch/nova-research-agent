# NOVA — Free AI Video Research Report

Generated: 2026-09-19T13:01:04.473959+00:00

## Decision rule
Scores are workflow-fit indicators, not guarantees. Free access, quotas and commercial rights can change by account, region, model and date.

| Tool | Score | Recurring free signal | Commercial use | Watermark |
|---|---:|---|---|---|
| Dreamina | 5/100 | No/unclear | UNCLEAR — verify before monetization | Unclear |
| Pika | 5/100 | No/unclear | UNCLEAR — verify before monetization | Unclear |
| Kling AI | 5/100 | No/unclear | UNCLEAR — verify before monetization | Unclear |
| Hailuo AI | 5/100 | No/unclear | UNCLEAR — verify before monetization | Unclear |
| Krea | 5/100 | No/unclear | UNCLEAR — verify before monetization | Unclear |
| Runway | 5/100 | No/unclear | UNCLEAR — verify before monetization | Unclear |
| Luma Dream Machine | 5/100 | No/unclear | UNCLEAR — verify before monetization | Unclear |
| CapCut | 5/100 | No/unclear | UNCLEAR — verify before monetization | Unclear |

## Recommended 0-DH workflow candidates

### Dreamina — 5/100
- Free signal: False
- Recurring signal: False
- Credits mentions: not detected
- Commercial: UNCLEAR — verify before monetization
- Watermark: Unclear

### Pika — 5/100
- Free signal: False
- Recurring signal: False
- Credits mentions: not detected
- Commercial: UNCLEAR — verify before monetization
- Watermark: Unclear

### Kling AI — 5/100
- Free signal: False
- Recurring signal: False
- Credits mentions: not detected
- Commercial: UNCLEAR — verify before monetization
- Watermark: Unclear

### Hailuo AI — 5/100
- Free signal: False
- Recurring signal: False
- Credits mentions: not detected
- Commercial: UNCLEAR — verify before monetization
- Watermark: Unclear

### Krea — 5/100
- Free signal: False
- Recurring signal: False
- Credits mentions: not detected
- Commercial: UNCLEAR — verify before monetization
- Watermark: Unclear

### Runway — 5/100
- Free signal: False
- Recurring signal: False
- Credits mentions: not detected
- Commercial: UNCLEAR — verify before monetization
- Watermark: Unclear

## Changes detected
No source-content changes detected against the latest stored snapshot.

## Discovery queries

### best free AI video generator 2026 recurring free credits
### AI video generator free plan commercial use watermark 2026
### free AI video text to video image to video pricing 2026
### free AI video generator TikTok Shorts Reels 2026