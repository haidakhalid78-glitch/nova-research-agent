# NOVA Free AI Video Research Agent

Autonomous, zero-cost research agent for tracking AI video tools that have a genuinely usable free path.

## What it does
- Checks official pricing/help/product pages plus web search results.
- Tracks free credits, renewal cadence, watermark status, resolution limits and commercial-use notes.
- Detects changes between runs.
- Scores tools for a 0-DH short-form video workflow.
- Produces Markdown + JSON reports.
- Stores snapshots locally in SQLite.
- Can run once or on a daily loop.
- Includes a Render cron blueprint, but local execution is the simplest zero-cost route.

## Important
"Free" is not treated as "commercially free". The agent flags commercial-use uncertainty rather than assuming monetization rights.

## Run locally

Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python agent.py --once
```

Daily loop:

```bash
python agent.py --daily
```

The latest report is written to `reports/latest.md` and `reports/latest.json`.

## Zero-DH design
No paid API is required. The agent uses public webpages and DuckDuckGo HTML search as a fallback discovery mechanism. It does not bypass logins, CAPTCHAs, paywalls or robots restrictions.

## Customization
Edit `sources.yaml` to add/remove tools and official pages.
Edit `config.yaml` to change the research topics and scoring weights.
